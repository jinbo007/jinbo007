# MEMORY.md - 长期记忆

## 技能位置

### 音乐下载 (music-downloader)
- **位置**: `/Users/jinbo/Documents/AIProject/clawbot/.trae/skills/music-downloader/SKILL.md`
- **用途**: 批量下载MP3音乐文件，从 myfreemp3.com.cn 网站搜索并下载音乐
- **使用时机**: 当用户需要下载歌曲时，立即调用此技能
- **关键步骤**: 搜索 → 播放页面 → 点击下载箭头 → 提取MP3链接 → 下载文件
- **下载路径**: `/Users/jinbo/Documents/AIProject/clawbot/mp3`

## 注意事项

- 智能匹配最佳版本，自动排除 DJ、cover、remix 等非原版版本
- 在播放页面必须点击下载箭头按钮才能获取真正的MP3链接
- 下载目录路径已记录，下载后可告知用户

---

*最后更新: 2025-06-20*
